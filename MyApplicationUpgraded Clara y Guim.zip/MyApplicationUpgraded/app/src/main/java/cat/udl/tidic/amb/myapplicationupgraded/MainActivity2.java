package cat.udl.tidic.amb.myapplicationupgraded;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity2 extends AppCompatActivity {

    EditText editTextName;
    EditText editTextDescription;
    Button backbutton;
    Button createbutton2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        createbutton2 = findViewById(R.id.create_button2);
        backbutton = findViewById(R.id.back_button);
        editTextName = findViewById(R.id.editText);
        editTextDescription = findViewById(R.id.editText2);

        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);
            }
        });

        createbutton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                startActivity(intent);
            }
        });
    }

    public void reset(View v){
        editTextName.setText("");
    }
}
